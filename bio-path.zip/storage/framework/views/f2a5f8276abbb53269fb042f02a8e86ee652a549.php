<?php $__env->startSection('content'); ?>
<style>
.form-group{overflow: hidden;}
</style>
<script src="http://listjs.com/assets/javascripts/list.min.js"></script>
<div id="wrapper">
    <?php echo $__env->make('layouts.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <main id="page-content-wrapper" role="main">
        <div class="col-sm-12">
            <div class="panel panel-default">
                <div class="panel-heading admin-panel"> 
                    <h2>Boi-Path Billing System</h2>  
                    <?php if(Session::has('msg')): ?>
                        <div class="alert alert-info"><?php echo e(Session::get('msg')); ?></div>
                    <?php endif; ?>        
                    <?php if(Session::has('delete')): ?>
                        <div class="alert alert-danger"><?php echo e(Session::get('delete')); ?></div>
                    <?php endif; ?>             
                </div>
                <div class="panel-body" id="allbill">
                    <div class="form-group">
                        <label class="col-sm-2" for="filter">Filter :</label>
                        <input class="search form-control col-sm-3" placeholder="Search" />
                    </div>               
                    <table class="table table-striped table-condensed table-responsive">
                        <thead>
                            <tr>
                                <th>RegNo.</th>
                                <th>Name</th>
                                <th>Father</th>
                                <th>Agent</th>
                                <th>Passport</th>
                                <th>Country</th>
                                <th>Reporting Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody class="list">
                        <?php $__currentLoopData = $billing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bill): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <tr>
                                <td class="regno"><?php echo e($bill->regno); ?></td>
                                <td class="name"><?php echo e($bill->name); ?></td>
                                <td><?php echo e($bill->father); ?></td>
                                <td class="recrutoffice"><?php echo e($bill->recrutoffice); ?></td>
                                <td class="passport"><?php echo e($bill->passport); ?></td>
                                <td><?php echo e($bill->country); ?></td>
                                <td><?php echo e($bill->reportdate); ?></td>
                                <td>
                                    <a href="<?php echo e(url('/testreports/create/'. $bill->id)); ?>" >Create Report</a> |
                                    <a href="<?php echo e(url('/#')); ?>" >View Report</a> |
                                    <a href="<?php echo e(url('/bill/'. $bill->id)); ?>" >View bill</a> |
                                    <a class="delete" href="<?php echo e(url('/bill/'. $bill->id.'/delete')); ?>">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>

    <script>
        var options = {
          valueNames: [ 'regno', 'name', 'recrutoffice', 'passport' ]
        };
        var userList = new List('allbill', options);
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>