<?php $__env->startSection('content'); ?>
<style>
.form-group{overflow: hidden;}
</style>
<div id="wrapper">
    <?php echo $__env->make('layouts.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <main id="page-content-wrapper" role="main">
        <div class="col-sm-12">
            <div class="panel panel-default">
                <?php echo Form::open(['url' => 'testreports/store', 'method'=>'post']); ?>

                  <div class="panel panel-info">
                    <div class="panel-heading">
                        <div class="panel-title">Medical Test Report</div>
                    </div>
                    <div class="panel-body">
                      <h4>Candidate Info</h4> 
                      <div class="form-group">
                        <?php echo Form::label('GCC Code', null, ['class'=> 'col-sm-2']); ?>

                        <?php echo Form::text('gcccode', null, ['class'=> 'form-control col-sm-2', 'required' => 'required']); ?>

                        <?php echo Form::label('GCC Slip No', null, ['class'=> 'col-sm-2']); ?>

                        <?php echo Form::text('gccslipno', null, ['class'=> 'form-control col-sm-2', 'required' => 'required']); ?>

                        <?php echo Form::label('Nationality', null, ['class'=> 'col-sm-2']); ?>

                        <?php echo Form::text('nationality', null, ['class'=> 'form-control col-sm-2']); ?>

                      </div>
                      <div class="form-group">
                        <?php echo Form::label('Height', null, ['class'=> 'col-sm-2']); ?>

                        <?php echo Form::text('height', null, ['class'=> 'form-control col-sm-2', 'required' => 'required']); ?>

                        <?php echo Form::label('Weight', null, ['class'=> 'col-sm-2']); ?>

                        <?php echo Form::text('weight', null, ['class'=> 'form-control col-sm-2', 'required' => 'required']); ?>

                        <?php echo Form::label('Profession', null, ['class'=> 'col-sm-2']); ?>

                        <?php echo Form::text('profession', null, ['class'=> 'form-control col-sm-2', 'required' => 'required']); ?>

                      </div>
                      <div class="form-group">
                        <?php echo Form::label('Visa No', null, ['class'=> 'col-sm-2']); ?>

                        <?php echo Form::text('visano', null, ['class'=> 'form-control col-sm-2', 'required' => 'required']); ?>

                        <?php echo Form::label('Visa Date', null, ['class'=> 'col-sm-2']); ?>

                        <?php echo Form::text('visadate', null, ['class'=> 'form-control col-sm-2 datepicker', 'required' => 'required']); ?>

                        <?php echo Form::label('MOFANO', null, ['class'=> 'col-sm-2']); ?>

                        <?php echo Form::text('mofano', null, ['class'=> 'form-control col-sm-2', 'required' => 'required']); ?> 
                      </div>
                      <h4>Medical Examination</h4>
                      <div class="form-group">
                        <?php echo Form::label('EYE', null, ['class'=> 'col-sm-2']); ?>

                        <?php echo Form::text('eye', null, ['class'=> 'form-control col-sm-2']); ?>

                        <?php echo Form::label('Commet', null, ['class'=> 'col-sm-2']); ?>

                        <?php echo Form::text('commet', null, ['class'=> 'form-control col-sm-2']); ?>

                        <?php echo Form::label('B.P', null, ['class'=> 'col-sm-2']); ?>

                        <?php echo Form::text('bp', null, ['class'=> 'form-control col-sm-2']); ?>

                      </div>
                      <div class="form-group">
                        <?php echo Form::label('Heart', null, ['class'=> 'col-sm-2']); ?>

                        <?php echo Form::text('heart', null, ['class'=> 'form-control col-sm-2']); ?>

                        <?php echo Form::label('LUNGS', null, ['class'=> 'col-sm-2']); ?>

                        <?php echo Form::text('lungs', null, ['class'=> 'form-control col-sm-2']); ?>

                        <?php echo Form::label('Chest X-ray', null, ['class'=> 'col-sm-2']); ?>

                        <?php echo Form::text('chestxray', null, ['class'=> 'form-control col-sm-2']); ?>

                      </div>
                      <div class="form-group">
                        <?php echo Form::label('Abdomen', null, ['class'=> 'col-sm-2']); ?>

                        <?php echo Form::text('abdomen', null, ['class'=> 'form-control col-sm-2']); ?>

                        <?php echo Form::label('Herina', null, ['class'=> 'col-sm-2']); ?>

                        <?php echo Form::text('herina', null, ['class'=> 'form-control col-sm-2']); ?>

                        <?php echo Form::label('Varicose Veins', null, ['class'=> 'col-sm-2']); ?>

                        <?php echo Form::text('varicoseveins', null, ['class'=> 'form-control col-sm-2']); ?>

                      </div>                      
                      <div class="form-group">
                        <?php echo Form::label('Extremities', null, ['class'=> 'col-sm-2']); ?>

                        <?php echo Form::text('extremities', null, ['class'=> 'form-control col-sm-2']); ?>

                        <?php echo Form::label('Deformities', null, ['class'=> 'col-sm-2']); ?>

                        <?php echo Form::text('deformities', null, ['class'=> 'form-control col-sm-2']); ?>

                        <?php echo Form::label('Skin', null, ['class'=> 'col-sm-2']); ?>

                        <?php echo Form::text('skin', null, ['class'=> 'form-control col-sm-2']); ?>

                      </div>
                      <div class="form-group">
                        <?php echo Form::label('Venereal Diseases', null, ['class'=> 'col-sm-2']); ?>

                        <?php echo Form::text('venerealdiseases', null, ['class'=> 'form-control col-sm-2']); ?>

                        <?php echo Form::label('C.N.S', null, ['class'=> 'col-sm-2']); ?>

                        <?php echo Form::text('cns', null, ['class'=> 'form-control col-sm-2']); ?>

                        <?php echo Form::label('Psychiatry', null, ['class'=> 'col-sm-2']); ?>

                        <?php echo Form::text('psychiatry', null, ['class'=> 'form-control col-sm-2']); ?>

                      </div> 
                      <h4>Laboratory Investigation</h4>
                      <div class="form-group">
                        <?php echo Form::label('Sugar', null, ['class'=> 'col-sm-2']); ?>

                        <?php echo Form::text('sugar', null, ['class'=> 'form-control col-sm-2']); ?>

                        <?php echo Form::label('Albumin', null, ['class'=> 'col-sm-2']); ?>

                        <?php echo Form::text('albumin', null, ['class'=> 'form-control col-sm-2']); ?>

                        <?php echo Form::label('Bilharziasis', null, ['class'=> 'col-sm-2']); ?>

                        <?php echo Form::text('bilharziasis', null, ['class'=> 'form-control col-sm-2']); ?>

                      </div>               
                      <div class="form-group">
                        <?php echo Form::label('Helminthes', null, ['class'=> 'col-sm-2']); ?>

                        <?php echo Form::text('helminthes', null, ['class'=> 'form-control col-sm-2']); ?>

                        <?php echo Form::label('Giardia', null, ['class'=> 'col-sm-2']); ?>

                        <?php echo Form::text('giardia', null, ['class'=> 'form-control col-sm-2']); ?>

                        <?php echo Form::label('Bilharziasis Culture', null, ['class'=> 'col-sm-2']); ?>

                        <?php echo Form::text('bilharziasisculture', null, ['class'=> 'form-control col-sm-2']); ?>

                      </div>              
                      <div class="form-group">
                        <?php echo Form::label('Salmonella', null, ['class'=> 'col-sm-2']); ?>

                        <?php echo Form::text('salmonella', null, ['class'=> 'form-control col-sm-2']); ?>

                        <?php echo Form::label('Cholera', null, ['class'=> 'col-sm-2']); ?>

                        <?php echo Form::text('cholera', null, ['class'=> 'form-control col-sm-2']); ?>

                        <?php echo Form::label('Blood Group', null, ['class'=> 'col-sm-2']); ?>

                        <?php echo Form::text('bloodgroup', null, ['class'=> 'form-control col-sm-2']); ?>

                      </div>             
                      <div class="form-group">
                        <?php echo Form::label('Haemoglobin', null, ['class'=> 'col-sm-2']); ?>

                        <?php echo Form::text('haemoglobin', null, ['class'=> 'form-control col-sm-2']); ?>

                        <?php echo Form::label('Thick Film For', null, ['class'=> 'col-sm-2']); ?>

                        <?php echo Form::text('thickfilmfor', null, ['class'=> 'form-control col-sm-2']); ?>

                        <?php echo Form::label('Malaria', null, ['class'=> 'col-sm-2']); ?>

                        <?php echo Form::text('malaria', null, ['class'=> 'form-control col-sm-2']); ?>

                      </div>           
                      <div class="form-group">
                        <?php echo Form::label('Micro Filaria', null, ['class'=> 'col-sm-2']); ?>

                        <?php echo Form::text('microfilaria', null, ['class'=> 'form-control col-sm-2']); ?>

                        <?php echo Form::label('R.B.S', null, ['class'=> 'col-sm-2']); ?>

                        <?php echo Form::text('rbs', null, ['class'=> 'form-control col-sm-2']); ?>

                        <?php echo Form::label('L.F.T.S', null, ['class'=> 'col-sm-2']); ?>

                        <?php echo Form::text('lfts', null, ['class'=> 'form-control col-sm-2']); ?>

                      </div>           
                      <div class="form-group">
                        <?php echo Form::label('Creatinine', null, ['class'=> 'col-sm-2']); ?>

                        <?php echo Form::text('creatinine', null, ['class'=> 'form-control col-sm-2']); ?>

                        <?php echo Form::label('HIV I & II', null, ['class'=> 'col-sm-2']); ?>

                        <?php echo Form::text('hiv', null, ['class'=> 'form-control col-sm-2']); ?>

                        <?php echo Form::label('HbsAg', null, ['class'=> 'col-sm-2']); ?>

                        <?php echo Form::text('hbsag', null, ['class'=> 'form-control col-sm-2']); ?>

                      </div>        
                      <div class="form-group">
                        <?php echo Form::label('Anti HCV', null, ['class'=> 'col-sm-2']); ?>

                        <?php echo Form::text('antihcv', null, ['class'=> 'form-control col-sm-2']); ?>

                        <?php echo Form::label('VDRL', null, ['class'=> 'col-sm-2']); ?>

                        <?php echo Form::text('vdrl', null, ['class'=> 'form-control col-sm-2']); ?>

                        <?php echo Form::label('TPHA', null, ['class'=> 'col-sm-2']); ?>

                        <?php echo Form::text('tpha', null, ['class'=> 'form-control col-sm-2']); ?>

                      </div> 
                      <div class="form-group">                      
                        <?php echo Form::label('Remarks', null, ['class'=> 'col-sm-2']); ?>

                        <?php echo Form::text('remarks', null, ['class'=> 'form-control col-sm-10']); ?>

                      </div>                      
                      <?php echo Form::submit('Submit', ['class'=> 'btn btn-primary']); ?>

                    <?php echo Form::close(); ?>

            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>


          
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>